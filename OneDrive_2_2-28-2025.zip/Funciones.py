import cv2

gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        erosion = cv2.erode(frame,kernel,iterations = 1)
       #erosion = cv2.erode(frame,kernel,iterations = 1)
# 	erosion = cv2.erode(frame,kernel,iterations = 1)

	#fgmask = cv2.dilate(fgmask, None, iterations=5)
fgmask = cv2.dilate(fgmask, None, iterations=5)
fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_CLOSE,  kernel)

fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_CLOSE, kernel)      
#lines= cv2.erode(img, kernel, iterations=1)
		#ret, frame = cap.read()
  
 #cnts, _ = cv2.findContours(gray, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		#cv2.drawContours(frame, cnts, -1, (0,0,255),2)        
		# Start by finding all of the connected components (white blobs in your image).
# 'im' needs to be grayscale and 8bit.
# 	nb_blobs, im_with_separated_blobs, stats, _ = cv2.connectedComponentsWithStats(gray)
# # im_with_separated_blobs is an image where each detected blob has a different pixel value ranging from 1 to nb_blobs - 1.
# # Here, we're interested only in the size of the blobs :
# 	sizes = stats[:, cv2.CC_STAT_AREA]
# # You can also directly index the column with '-1' instead of 'cv2.CC_STAT_AREA' as it's the last column.

# # A small gotcha is that the background is considered as a blob, and so its stats are included in the stats vector at position 0.

# # minimum size of particles we want to keep (number of pixels).
# # here, it's a fixed value, but you can set it as you want, eg the mean of the sizes or whatever.
# 	min_size = 150  

# # create empty output image with will contain only the biggest composents
# 	fgmask = np.zeros_like(im_with_separated_blobs)

# for every component in the image, keep it only if it's above min_size.
# # we start at 1 to avoid considering the background
# 	for index_blob in range(1, nb_blobs):
# 		if sizes[index_blob] >= min_size:
# 			#im_result[im_with_separated_blobs == index_blob] = 255
# 			fgmask[im_with_separated_blobs == index_blob] = 255


 #cnts, _ = cv2.findContours(gray, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		#cv2.drawContours(frame, cnts, -1, (0,0,255),2)        
		# Start by finding all of the connected components (white blobs in your image).
# 'im' needs to be grayscale and 8bit.
# 	nb_blobs, im_with_separated_blobs, stats, _ = cv2.connectedComponentsWithStats(gray)
# # im_with_separated_blobs is an image where each detected blob has a different pixel value ranging from 1 to nb_blobs - 1.
# # Here, we're interested only in the size of the blobs :
# 	sizes = stats[:, cv2.CC_STAT_AREA]
# # You can also directly index the column with '-1' instead of 'cv2.CC_STAT_AREA' as it's the last column.

# # A small gotcha is that the background is considered as a blob, and so its stats are included in the stats vector at position 0.
#fondo = cv2.imread('images/fondo.png')
#image = cv2.imread('test.jpg')

	#_, cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)	 