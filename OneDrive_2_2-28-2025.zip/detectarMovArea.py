import cv2
import numpy as np

#cap = cv2.VideoCapture('autos.mp4')
#cap = cv2.VideoCapture(0)
cap = cv2.VideoCapture('videos/vidrio20.mp4')

fgbg = cv2.bgsegm.createBackgroundSubtractorMOG()
#kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))
texto_estado = "Estado: No se ha detectado movimiento"
color = (0, 255, 0)

while True:

	ret, frame = cap.read()
	if ret == False: break

	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	# Dibujamos un rectángulo en frame, para señalar el estado
	# del área en análisis (movimiento detectado o no detectado)
	cv2.rectangle(frame,(0,0),(frame.shape[1],40),(0,0,0),-1)

	# Especificamos los puntos extremos del área a analizar
	#area_pts = np.array([[240,320], [480,320], [620,frame.shape[0]], [50,frame.shape[0]]])
	#area_pts = np.array([[300,300], [500,300], [500,200], [300,200]])
	
 	#Rectangulo pequeño	
	#area_pts = np.array([[200,80], [300,80], [300,100], [200,100]])
	#area_pts = np.array([[50,80], [500,80], [500,300], [50,300]])
	#area_pts = np.array([[50,80], [200,80], [200,200], [50,200]])
	area_pts = np.array([[50,50], [600,50], [600,300], [50,300]])

	# Con ayuda de una imagen auxiliar, determinamos el área
	# sobre la cual actuará el detector de movimiento
	#imAux = np.zeros(shape=(frame.shape[:2]), dtype=np.uint8)
	#imAux = cv2.drawContours(imAux, [area_pts], -1, (255), -1)
	#image_area = cv2.bitwise_and(gray, gray, mask=imAux)

	# Obtendremos la imagen binaria donde la región en blanco representa
	# la existencia de movimiento
	#fgmask = fgbg.apply(image_area)
	fgmask = fgbg.apply(frame)
	#fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)
	#fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)
	#kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(100,1))
	#kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1,1))
	#kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1,1))
	kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(2,2))
	#kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))
	#gradient = cv2.morphologyEx(gray, cv2.MORPH_GRADIENT, kernel)   	
	fgmask = cv2.morphologyEx(frame, cv2.MORPH_GRADIENT, kernel)
	#fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_CLOSE, kernel)
	fgmask = cv2.dilate(frame, None, iterations=1)

	# Encontramos los contornos presentes en fgmask, para luego basándonos
	# en su área poder determina si existe movimiento
	cnts = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
	#cnts = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[0]
	for cnt in cnts:
		if cv2.contourArea(cnt) > 500:
			x, y, w, h = cv2.boundingRect(cnt)
			cv2.rectangle(frame, (x,y), (x+w, y+h),(0,255,0), 2)
			texto_estado = "Estado: ALERTA Movimiento Detectado!"
			color = (0, 0, 255)	

	# Visuzalizamos el alrededor del área que vamos a analizar
	# y el estado de la detección de movimiento		
	cv2.drawContours(frame, [area_pts], -1, color, 2)
	cv2.putText(frame, texto_estado , (10, 30),
				cv2.FONT_HERSHEY_SIMPLEX, 1, color,2)

	cv2.imshow('fgmask', fgmask)
	cv2.imshow("frame", frame)

	k = cv2.waitKey(80) & 0xFF
	if k == 27:
		break

cap.release()
cv2.destroyAllWindows()