import cv2
import numpy as np
#from skimage import io              # Only needed for web reading images

# Web read image; use cv2.imread(...) for local images
img = cv2.imread("images/gaps.png") 
#img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#img = cv2.cvtColor(io.imread('https://i.sstatic.net/jnCvG.jpg'), cv2.COLOR_RGB2GRAY)

# Get rid of JPG artifacts
img = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY)[1]

# Create structuring elements
horizontal_size = 9
vertical_size = 9
horizontalStructure = cv2.getStructuringElement(cv2.MORPH_RECT, (horizontal_size, 1))
verticalStructure = cv2.getStructuringElement(cv2.MORPH_RECT, (1, vertical_size))

# Morphological opening
mask1 = cv2.morphologyEx(img, cv2.MORPH_OPEN, horizontalStructure)
mask2 = cv2.morphologyEx(img, cv2.MORPH_OPEN, verticalStructure)

# Outputs
cv2.imshow('img', img)
cv2.imshow('mask1', mask1)
cv2.imshow('mask2', mask2)
cv2.waitKey(0)
cv2.destroyAllWindows()