import pyodbc


            #print(seconds)
    #print("Done")
# # Calculate the end time and time taken
# end = time.time()
# length = end - start

# # Show the results : this can be altered however you like
# print("It took", length, "seconds!")
class GuardarSQL ():
    #def __init__(self):
    
   

#print(cursor.rowcount, "record(s) affected")
#val = (pz)
#cursor.execute(sql, val)
#sql = "UPDATE Tbl_Conteos_Estados SET PzMov = %s WHERE Con_Linea = %s"
#val = [1, 331]
#cursor.execute(sql, val)


# SQLCommand = ("INSERT INTO TblConteos (codlinea,TicketGem,Nopuerto) VALUES (?,?,?);") 
# Values = ['333','101010','0']

# #Processing Query    
# cursor.execute(SQLCommand,Values)

# cnxn.commit()
# print("Data Successfully Inserted")   

#str='hello'
#cursor.execute("UPDATE users SET message = '" + str + "' WHERE UserId=13")

#cursor.execute("UPDATE Tbl_Conteos_Estados SET PzMov=1 WHERE Con_Linea=331")

#Year= 2000
#sql_update_query = "Update Tbl_Conteos_Estados set PzMov = '" + valor + "' where Con_Linea = 331"
#cursor.execute(sql_update_query)
# SELECT        TOP (200) Con_Id, Con_Estado, Con_EstadoPC, , Con_Folio, Est_Sensores, Est_Timer, PulseWidthLow1, PulseWidthHigh1, PulseWidthLow2, PulseWidthHigh2, PulseWidthLow3, PulseWidthHigh3, Con_Ticket, 
#                          Con_fecha, DelayLow1, DelayHigh1
# FROM            
# cursor.execute ("UPDATE Tbl_Conteos_Estados   SET PzMov= (?)   WHERE Con_Linea=331", (Year))
#SQLCommand =("UPDATE Tbl_Conteos_Estados   SET PzMov= (?)   WHERE Con_Linea=331") 


#SQLCommand = ("INSERT INTO TblConteos (codlinea,TicketGem,Nopuerto) VALUES (?,?,?);") 
#Values = ['333','101010','0']

#sql = "UPDATE Tbl_Conteos_Estados SET PzMov=%s WHERE Con_Linea=331 VALUES(%s)"
#val = (2000)

#cursor.execute(sql, val)

#sql = """ UPDATE Tbl_Conteos_Estados SET PzMov=%s WHERE Con_Linea = 331 """
#val = (email, first, last, phone, passw, user)