import cv2
import numpy as np
import imutils
import random as rng
from funciones.tracker import *
#cap = cv2.VideoCapture(0)
cap = cv2.VideoCapture('videos/vidrio23.mp4')

#fgbg = cv2.bgsegm.createBackgroundSubtractorMOG()
#fgbg = cv2.bgsegm.createBackgroundSubtractorMOG()
#fgbg = cv2.createBackgroundSubtractorMOG2() 
fgbg = cv2.createBackgroundSubtractorMOG2() 
#fgbg = cv2.bgsegm.createBackgroundSubtractorGMG()
tracker = EuclideanDistTracker() # type: ignore

def nothing(pos):
	pass
#kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(5,5))
#kernel = cv2.getStructuringElement(cv2.MORPH_CROSS,(20,100))
#color = (0, 255, 0)
cv2.namedWindow('Thresholds')
cv2.createTrackbar('LS','Thresholds',255,255, nothing)
cv2.createTrackbar('LH','Thresholds',255,255, nothing)
cv2.createTrackbar('TS','Thresholds',127,255, nothing)
cv2.createTrackbar('TH','Thresholds',255,255, nothing)

i=0
 

while True:
	_, frame = cap.read()
	#kernel = np.ones((3,15), np.unit8)
	#lines= cv2.erode(img, kernel, iterations=1)
	ret, frame = cap.read()
	if ret == False: break
	
 # Setting parameter values 
	ls=cv2.getTrackbarPos('LS','Thresholds')
	lh=cv2.getTrackbarPos('LH','Thresholds')
	ts=cv2.getTrackbarPos('TS','Thresholds')
	th=cv2.getTrackbarPos('TH','Thresholds')
 
	#min=cv2.getTrackbarPos('Min','Thresholds')
	#max=cv2.getTrackbarPos('Min','Thresholds')
	#gray = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
	#thresh = cv2.threshold(gray, args["threshold"], 255,
	#cv2.THRESH_BINARY)[1]
 
    # clone our original image (so we can draw on it) and then draw
    # a bounding box surrounding the connected component along with
    # a circle corresponding to the centroid
	#output = image.copy()
	# cv2.rectangle(output, (x, y), (x + w, y + h), (0, 255, 0), 3)
	# cv2.circle(output, (int(cX), int(cY)), 4, (0, 0, 255), -1)    

    # construct a mask for the current connected component by
    # finding a pixels in the labels array that have the current
    # connected component ID
	#componentMask = (labels == i).astype("uint8") * 255
    # show our output image and connected component mask
	#cv2.imshow("Output", output)
	#cv2.imshow("Connected Component", componentMask)
 
	# gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	# #fgmask = fgbg.apply(frame)
	# fgmask = fgbg.apply(gray)
	# fgmask = cv2.dilate(fgmask, None, iterations=1)
    
	#gray = cv2.imread('image.png', cv2.IMREAD_UNCHANGED)
	#gray = cv2.cvtColor(img, cv2.IMREAD_UNCHANGED)
	#gray = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
	#gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #COLOR_BGR2GRAY
	#edges = cv2.Canny(gray, 100, 200)
 
	#binary = cv2.threshold(gray, ls, lh, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
	#binary = cv2.threshold(gray, ls, lh, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
	#ret,thresh = cv2.threshold(img, umbral, valorMax , tipo)	
	#binary = cv2.threshold(gray, 125, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
	#binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
	#img = cv2.imread('matizGris.png',0)
	#ret,thresh = cv2.threshold(img,ls,lh,cv2.THRESH_BINARY_INV)
	#ret,thresh = cv2.threshold(img,ls,lh,cv2.THRESH_TOZERO)
	#_, thresh = cv2.threshold(img,0,255,cv2.THRESH_OTSU)
	#ret, thresh = cv2.threshold(gray,0, lth, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
	#print('Umbral de th1:', ret)
 
 # Apply global (simple) thresholding on image
	#ret1,thresh1 = cv2.threshold(lines,127,255,cv2.THRESH_BINARY)

# Apply Otsu's thresholding on image
	#ret2,thresh2 = cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)

# Apply Otsu's thresholding after Gaussian filtering
	#blur = cv2.GaussianBlur(img,(5,5),0)
	#ret3,thresh3 = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
  
	#ret,thresh = cv2.threshold(fgmask,ls,lh,cv2.THRESH_BINARY)
    #cv2.bitwise_not(threshold, threshold)
    
 # convert image to grayscale image
	gray_image = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
 
# Applying the Canny Edge filter 
	edges = cv2.Canny(gray_image, ls, lh) 
	fgmask = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
	#fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)
 
	cv2.imshow("fgmask", fgmask)
 
# convert the grayscale image to binary image
	ret,thresh = cv2.threshold(gray_image,ts,th,0)
	#cv2.imshow("edges", edges)
	cv2.imshow("thresh", thresh)
	#canny_output = cv2.Canny(gray_image, thresh, thresh * 2)
	contours,hierarchy=cv2.findContours(thresh,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
	# calculate moments of binary image
	M = cv2.moments(thresh)
	if M["m00"] != 0:
		# calculate x,y coordinate of center
		cX = int(M["m10"] / M["m00"])
		cY = int(M["m01"] / M["m00"])
	
	
		# display the image
		cv2.imshow("Image", frame)
		#cv2.waitKey(0)
		
    # # Draw contours
	detections = []
	contornos, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
 
   # Get the moments
	mu = [None]*len(contours)
	for i in range(len(contours)):
		mu[i] = cv2.moments(contours[i])
 
		# put text and highlight the center
#		cv2.circle(frame, (cX, cY), 5, (0, 0, 255), -1)
  
    # Get the mass centers
	mc = [None]*len(contours)
	for i in range(len(contours)):
        # add 1e-5 to avoid division by zero
		mc[i] = (mu[i]['m10'] / (mu[i]['m00'] + 1e-5), mu[i]['m01'] / (mu[i]['m00'] + 1e-5))
 
    
	drawing = np.zeros((edges.shape[0], edges.shape[1], 3), dtype=np.uint8)
    
	for i in range(len(contours)):
		color = (rng.randint(0,256), rng.randint(0,256), rng.randint(0,256))
		cv2.drawContours(drawing, contours, i, color, 2)
		cv2.circle(drawing, (int(mc[i][0]), int(mc[i][1])), 4, color, -1)
		cv2.putText(frame, "centroid", (cX - 25, cY - 25),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
		#cv2.putText(frame, "centroid", ((int(mc[i][0]) - 25, int(mc[i][1]) - 25),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2))
    
    
	#contours = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
	#cnts = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[0]
	#f.write("Number of white pixels:"+ "\n")
    
	for cnt in contornos:
		print(cv2.contourArea(cnt))
		#if cv2.contourArea(cnt) > 10000:
			#print(detections)					

		if cv2.contourArea(cnt) > 1000:
		#if w > 300:
			(x, y, w, h) = cv2.boundingRect(cnt)
			rect = cv2.minAreaRect(cnt)
			centerX = rect[0][0]
			box = cv2.boxPoints(rect)
			box = np.int_(box)
			cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 3)
			cv2.drawContours(frame,[box],0,(0,222,0),2)
			detections.append([x, y, w, h])
			#center= box.
			boxers_ids = tracker.update(detections)
			for box_id in boxers_ids:
				x, y, w, h, id = box_id
				#cv2.putText(frame,  str(id) , (x, y - 15),cv2.FONT_HERSHEY_PLAIN, 3, (0, 0, 255), 2)
				cv2.putText(frame,  str(id) , (cX, cY - 15),cv2.FONT_HERSHEY_PLAIN, 3, (0, 0, 255), 2)
				#cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 3)
			#if 450 > w > 300:
			# calculate x,y coordinate of center
			# cv2.waitKey() 
			# m = cv2.moments(i)
			# # if m["m00"] != 0:
			# 	cX = int(m["m10"] /  m["m00"]) 
			# 	cY = int(m["m01"] / m["m00"])
			# 	cv2.circle(frame, (int(cX), int(cY)), 3, (0, 0, 255), -1)    
			# 		#cv2.putText(frame, "center: " + str((rect[0])) , (cX - 25, cY - 45),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
					#cv2.putText(frame, "centroid: " + str((cX, cY)) , (cX - 25, cY - 25),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
					#cv2.putText(frame, "w: " + str(w) + ", h:" + str(h), (cX,cY+10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 1)
					#cv2.putText(frame, "area: " + str(cv2.contourArea(cnt)), (cX,cY+50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 1)
					# if 305 > centerX > 290:
					# 	#if x < 400:
					# 	counter  +=1
      
     
				#cv2.rectangle(frame, (x,y), (x+w, y+h),(0,255,0), 2)
				#number_of_white_pix = np.sum(fgmask == 255) 
					#cv2.putText(frame, "centroid", ((int(m[0]) - 25, int(m[1]) - 25),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2))
	cv2.imshow('Contours', drawing)
   
	#cv2.imshow('result', result) 
	#cv2.imshow('edges', edges) 
	#cv2.putText(frame, str(counter), (500,20), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 1)
	cv2.line(frame, (200,0), (200,500), (0, 0, 255), 2)
	cv2.line(frame, (350,0), (350,500), (0, 255, 255), 1)
	cv2.line(frame, (400,0), (400,500), (0, 255, 255), 1)
	cv2.imshow('fgmask', fgmask) 
	cv2.imshow('frame',frame ) 
    # Calculate the area with the moments 00 and compare with the result of the OpenCV function
	# for i in range(len(contours)):
	# 	print(' * Contour[%d] - Area (M_00) = %.2f - Area OpenCV: %.2f - Length: %.2f' % (i, mu[i]['m00'], cv2.contourArea(contours[i]), cv2.arcLength(contours[i], True)))
 


	# cv2.imshow('img', thresh)
	# cv2.imshow("Contour",fgmask)
	# cv2.imshow("Contour",frame)
 
	 
	k = cv2.waitKey(80) & 0xFF
	if k == 27:
		break
 
cap.release()
cv2.destroyAllWindows()