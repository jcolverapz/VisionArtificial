import cv2
import numpy as np
import imutils
import random as rng
#cap = cv2.VideoCapture(0)
cap = cv2.VideoCapture('videos/vidrio22.mp4')

fgbg = cv2.bgsegm.createBackgroundSubtractorMOG()

def nothing(pos):
	pass
kernel = np.ones((1,20), np.uint8)  # note this is a horizontal kernel#kernel = cv2.getStructuringElement(cv2.MORPH_CROSS,(20,100))

cv2.namedWindow('Thresholds')
cv2.createTrackbar('LS','Thresholds',160,255, nothing)
cv2.createTrackbar('LH','Thresholds',255,255, nothing)

i=0
 
while True:
	ret, frame = cap.read()
	
	if ret == False: break
	
	ls=cv2.getTrackbarPos('LS','Thresholds')
	lh=cv2.getTrackbarPos('LH','Thresholds')
	
 
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	fgmask = fgbg.apply(frame)
  
	ret,thresh = cv2.threshold(gray,ls,lh,cv2.THRESH_BINARY)	
 
	cv2.imshow("Imagen", thresh)
# find contours in the binary image

	contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
	cv2.drawContours(frame,contours,-1,(0,255,0),4)
	 
# display the image
	cv2.imshow("Image", frame)
#cv2.imshow("Image", frame)
#cv2.waitKey(0)

	 
	k = cv2.waitKey(80) & 0xFF
	if k == 27:
		break
 
cap.release()
cv2.destroyAllWindows()
	#gray = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
	#thresh = cv2.threshold(gray, args["threshold"], 255,
	#cv2.THRESH_BINARY)[1]
 
    # clone our original image (so we can draw on it) and then draw
    # a bounding box surrounding the connected component along with
    # a circle corresponding to the centroid
	#output = image.copy()
	# cv2.rectangle(output, (x, y), (x + w, y + h), (0, 255, 0), 3)
	# cv2.circle(output, (int(cX), int(cY)), 4, (0, 0, 255), -1)    

    # construct a mask for the current connected component by
    # finding a pixels in the labels array that have the current
    # connected component ID
	#componentMask = (labels == i).astype("uint8") * 255
    # show our output image and connected component mask
	#cv2.imshow("Output", output)
	#cv2.imshow("Connected Component", componentMask)