import cv2
import numpy as np
import imutils

cap = cv2.VideoCapture('videos/vidrio23.mp4')

#fgbg = cv2.bgsegm.createBackgroundSubtractorMOG()
fgbg = cv2.createBackgroundSubtractorMOG2()

def nothing(pos):
	pass

kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))
#kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(1,15))

cv2.namedWindow('Thresholds')
cv2.createTrackbar('LH','Thresholds',180,255, nothing)
cv2.createTrackbar('LS','Thresholds',45,255, nothing)

while True:
	ret, frame = cap.read()
	if ret == False: break
	
	lh=cv2.getTrackbarPos('LH','Thresholds')
	ls=cv2.getTrackbarPos('LS','Thresholds')
	   
	#image = cv2.imread('image.png', cv2.IMREAD_UNCHANGED)
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	#gray = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
	#binary = cv2.threshold(gray, ls, lh, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
	#binary = cv2.threshold(gray, ls, lh, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
	#binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
	#binary = cv2.threshold(gray, lh, ls, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
	#binary = cv2.threshold(gray, lh, ls, cv2.THRESH_BINARY_INV)[1]
	binary = cv2.threshold(gray, lh, ls, cv2.THRESH_BINARY)[1]
	fgmask = cv2.dilate(binary, None, iterations=5)
	#fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)
	fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_CLOSE, kernel)
	#fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)
 #binary = cv2.threshold(frame,127,255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    # getting mask with connectComponents
	#ret, labels = cv2.connectedComponents(binary)
	# ret, labels = cv2.connectedComponents(binary)
	# #ret, labels = cv2.connectedComponents(gray)
	# for label in range(1,ret):
	# 	mask = np.array(labels, dtype=np.uint8)
	# 	#mask[labels == label] = 255
	# 	mask[labels == label] = 0
	# 	cv2.imshow('component',mask)
	# #cv2.waitKey(0)
	area_pts = np.array([[50,10], [715,10], [715,500], [50,500]])
	imAux = np.zeros(shape=(frame.shape[:2]), dtype=np.uint8)
	imAux = cv2.drawContours(imAux, [area_pts], -1,(255), -1)
	fgmask = fgbg.apply(binary)
 
	#contours, hierarchy = cv2.findContours(fgmask, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
	contours, hierarchy = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	#contours, hierarchy = cv2.findContours(fgmask, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
	#cv2.drawContours(fgmask, [hull], -1, (255,255,255), 5)
	contours = sorted(contours, key=lambda x: cv2.contourArea(x), reverse=True)	
	cv2.putText(frame, "contours: " + str ((len(contours))),(20,20),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
	for cnt in contours:
     
		if cv2.contourArea(cnt) > 1000:#convexHull = cv2.convexHull(contour)
			cv2.drawContours(frame,cnt,-1,(0,255,0),4)
			#cv2.waitKey() 
		#cv2.drawContours(frame, [convexHull], -1, (0, 255, 0), 2)
			#print(str(cv2.contourArea(cnt)))
		#cv2.waitKey(0)

# Display the final convex hull image
	#cv2.imshow('ConvexHull', frame) 
    
    
    
	# gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	 
 	# #Areas big
	# #area_pts = np.array([[50,10], [715,10], [715,500], [50,500]])
	 
 	# # Con ayuda de una imagen auxiliar, determinamos el área
	# # sobre la cual actuará el detector de movimiento
	# #imAux = np.zeros(shape=(frame.shape[:2]), dtype=np.uint8)
	 
	# #imAux = cv2.drawContours(imAux, [area_pts], -1,(255), -1)
  
	# fgmask = fgbg.apply(frame)
  
	# # Marker labelling
	# ret, markers = cv2.connectedComponents(fgmask)
 
	# # Set up the detector with default parameters.
	# detector = cv2.SimpleBlobDetector()
	
	# # Detect blobs.
	# keypoints = detector.detect(fgmask)
	
	# # Draw detected blobs as red circles.
	# # cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS ensures the size of the circle corresponds to the size of blob
	# im_with_keypoints = cv2.drawKeypoints(fgmask, keypoints, np.array([]), (0,0,255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
	
	# Show keypoints
	#cv2.imshow("Keypoints", im_with_keypoints)
 
	cv2.imshow("frame", frame)
	cv2.imshow('fgmask', fgmask)
	
	#cv2.imshow("frame", frame)
	#cv2.imshow('fgmask', fgmask)
	 
	k = cv2.waitKey(80) & 0xFF
	if k == 27:
		break
 
cap.release()
cv2.destroyAllWindows()