import imutils
import cv2
import numpy as np
 
cap = cv2.VideoCapture('videos/vidrio23.mp4')
def nothing(pos):
	pass
cv2.namedWindow('Thresholds')
cv2.createTrackbar('LS','Thresholds',160,255, nothing)
cv2.createTrackbar('LH','Thresholds',255,255, nothing)

i = 0
while True:
	ret, frame = cap.read()
	if ret == False: break
	# load the image, convert it to grayscale, and blur it slightly
	#image = cv2.imread("images/extreme_points_input.png")
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	
	#Gaussian = cv2.GaussianBlur(gray, (5, 5), 0)
	Gaussian = cv2.GaussianBlur(gray, (1, 1), 0)
	# threshold the image, then perform a series of erosions +
	# dilations to remove any small regions of noise
	ls=cv2.getTrackbarPos('LS','Thresholds')
	lh=cv2.getTrackbarPos('LH','Thresholds')
	thresh = cv2.threshold(Gaussian, ls, lh, cv2.THRESH_BINARY)[1]
	#thresh = cv2.erode(thresh, None, iterations=2)
	thresh = cv2.dilate(thresh, None, iterations=1)
	# find contours in thresholded image, then grab the largest
	# one
	cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
	cnts = imutils.grab_contours(cnts)
	
	for cnt in cnts:
		c = max(cnts, key=cv2.contourArea)
	# determine the most extreme points along the contour
		extLeft = tuple(c[c[:, :, 0].argmin()][0])
		extRight = tuple(c[c[:, :, 0].argmax()][0])
		extTop = tuple(c[c[:, :, 1].argmin()][0])
		extBot = tuple(c[c[:, :, 1].argmax()][0])
	# draw the outline of the object, then draw each of the
	# extreme points, where the left-most is red, right-most
	# is green, top-most is blue, and bottom-most is teal
		cv2.drawContours(frame, [c], -1, (0, 255, 255), 2)
		cv2.circle(frame, extLeft, 8, (0, 0, 255), -1)
		cv2.circle(frame, extRight, 8, (0, 255, 0), -1)
		cv2.circle(frame, extTop, 8, (255, 0, 0), -1)
		cv2.circle(frame, extBot, 8, (255, 255, 0), -1)
		

# show the output image
	cv2.imshow("Image", frame)
	cv2.imshow("Gaussian", Gaussian)
	cv2.imshow("Gaussian", thresh)
	k = cv2.waitKey(80) & 0xFF
	if k == 27:
		break
 
cap.release()
cv2.destroyAllWindows()


#	cv2.drawContours(frame,countours,-1,(0,255,0),4)
# # 		#print(cv2.contourArea(cnt))
		# if cv2.contourArea(cnt) > 10000:
# # 		if cv2.contourArea(cnt) > 1000:
			#(x, y, w, h) = cv2.boundingRect(cnt)
# 			(x, y, w, h) = cv2.boundingRect(cnt)
# # 			#band1 = True
			#cv2.rectangle(frame, (x,y), (x+w, y+h),(0,255,255), 3)
# # 			number_of_white_pix = np.sum(fgmask == 255)
